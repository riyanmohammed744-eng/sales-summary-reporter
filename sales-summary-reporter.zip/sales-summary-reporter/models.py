"""
models.py — Foundational data structures for Sales Summary Reporter.
Uses dataclasses to model core record attributes and operational states.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field, asdict
from datetime import date, datetime
from typing import Optional


@dataclass
class SaleRecord:
    """Represents a single sales transaction."""
    sale_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8].upper())
    date: str = ""                # YYYY-MM-DD
    product_name: str = ""
    category: str = ""
    quantity: int = 0
    unit_price: float = 0.0
    total_price: float = 0.0
    payment_method: str = "Cash"  # Cash | Card | UPI | Online
    customer_name: str = "Walk-in"
    notes: str = ""

    def __post_init__(self):
        self.total_price = round(self.quantity * self.unit_price, 2)

    def recalculate(self):
        self.total_price = round(self.quantity * self.unit_price, 2)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> SaleRecord:
        return cls(
            sale_id=str(d.get("sale_id", uuid.uuid4().hex[:8].upper())),
            date=str(d.get("date", "")),
            product_name=str(d.get("product_name", "")),
            category=str(d.get("category", "")),
            quantity=int(d.get("quantity", 0)),
            unit_price=float(d.get("unit_price", 0.0)),
            total_price=float(d.get("total_price", 0.0)),
            payment_method=str(d.get("payment_method", "Cash")),
            customer_name=str(d.get("customer_name", "Walk-in")),
            notes=str(d.get("notes", "")),
        )


VALID_CATEGORIES = [
    "Electronics", "Groceries", "Clothing", "Stationery",
    "Beverages", "Snacks", "Personal Care", "Home & Kitchen",
    "Sports", "Toys", "Books", "Other",
]

VALID_PAYMENT_METHODS = ["Cash", "Card", "UPI", "Online"]

# Threshold configuration for warnings
THRESHOLDS = {
    "low_stock_quantity": 2,
    "high_value_sale": 5000.0,
    "daily_target": 10000.0,
    "anomaly_multiplier": 3.0,  # flag if single sale > 3× avg
}
