"""
analytics.py — Core business logic engine for Sales Summary Reporter.
Computes daily totals, product totals, category breakdowns,
threshold warnings, and executive summary metrics.
"""

from __future__ import annotations

from collections import defaultdict
from typing import List, Dict, Any, Optional
from models import SaleRecord, THRESHOLDS


def compute_daily_totals(records: List[SaleRecord]) -> Dict[str, Dict[str, Any]]:
    """
    Aggregate sales by date.
    Returns {date_str: {count, units, revenue, avg_sale}}.
    """
    agg = defaultdict(lambda: {"count": 0, "units": 0, "revenue": 0.0})
    for r in records:
        d = agg[r.date]
        d["count"] += 1
        d["units"] += r.quantity
        d["revenue"] += r.total_price
    # compute averages
    for dt, d in agg.items():
        d["avg_sale"] = round(d["revenue"] / d["count"], 2) if d["count"] else 0
    return dict(agg)


def compute_product_totals(records: List[SaleRecord]) -> Dict[str, Dict[str, Any]]:
    """
    Aggregate sales by product name.
    Returns {product_name: {units, revenue, transactions, avg_price}}.
    """
    agg = defaultdict(lambda: {"units": 0, "revenue": 0.0, "transactions": 0})
    for r in records:
        d = agg[r.product_name]
        d["units"] += r.quantity
        d["revenue"] += r.total_price
        d["transactions"] += 1
    for prod, d in agg.items():
        d["avg_price"] = round(d["revenue"] / d["units"], 2) if d["units"] else 0
    return dict(agg)


def compute_category_totals(records: List[SaleRecord]) -> Dict[str, Dict[str, Any]]:
    """Aggregate sales by category."""
    agg = defaultdict(lambda: {"count": 0, "units": 0, "revenue": 0.0})
    for r in records:
        d = agg[r.category]
        d["count"] += 1
        d["units"] += r.quantity
        d["revenue"] += r.total_price
    return dict(agg)


def compute_payment_breakdown(records: List[SaleRecord]) -> Dict[str, Dict[str, Any]]:
    """Aggregate by payment method."""
    agg = defaultdict(lambda: {"count": 0, "revenue": 0.0})
    for r in records:
        d = agg[r.payment_method]
        d["count"] += 1
        d["revenue"] += r.total_price
    return dict(agg)


def compute_executive_summary(records: List[SaleRecord]) -> Dict[str, Any]:
    """
    Comprehensive summary with totals, averages, trends, and status indicators.
    """
    if not records:
        return {
            "total_revenue": 0, "total_transactions": 0, "total_units": 0,
            "avg_sale_value": 0, "unique_products": 0, "unique_categories": 0,
            "date_range": "N/A", "daily_totals": {}, "product_totals": {},
            "category_totals": {}, "payment_breakdown": {},
            "top_product": "N/A", "top_category": "N/A",
            "busiest_day": "N/A", "warnings": [],
        }

    total_revenue = sum(r.total_price for r in records)
    total_units = sum(r.quantity for r in records)
    dates = sorted(set(r.date for r in records))
    daily = compute_daily_totals(records)
    products = compute_product_totals(records)
    categories = compute_category_totals(records)
    payments = compute_payment_breakdown(records)

    top_product = max(products.items(), key=lambda x: x[1]["revenue"])[0] if products else "N/A"
    top_category = max(categories.items(), key=lambda x: x[1]["revenue"])[0] if categories else "N/A"
    busiest_day = max(daily.items(), key=lambda x: x[1]["revenue"])[0] if daily else "N/A"

    summary = {
        "total_revenue": round(total_revenue, 2),
        "total_transactions": len(records),
        "total_units": total_units,
        "avg_sale_value": round(total_revenue / len(records), 2),
        "unique_products": len(set(r.product_name for r in records)),
        "unique_categories": len(set(r.category for r in records)),
        "date_range": f"{dates[0]} to {dates[-1]}" if dates else "N/A",
        "daily_totals": daily,
        "product_totals": products,
        "category_totals": categories,
        "payment_breakdown": payments,
        "top_product": top_product,
        "top_category": top_category,
        "busiest_day": busiest_day,
        "warnings": generate_warnings(records, daily, products),
    }
    return summary


def generate_warnings(
    records: List[SaleRecord],
    daily: Dict[str, Dict],
    products: Dict[str, Dict],
) -> List[Dict[str, str]]:
    """
    Threshold-based warning indicators.
    Returns list of {level, message} dicts.
    """
    warnings = []
    avg_sale = sum(r.total_price for r in records) / len(records) if records else 0

    # High-value sale warnings
    for r in records:
        if r.total_price > THRESHOLDS["high_value_sale"]:
            warnings.append({
                "level": "info",
                "message": f"High-value sale: {r.product_name} on {r.date} — ₹{r.total_price:,.2f}",
            })

    # Anomaly detection: single sale > 3× average
    for r in records:
        if avg_sale > 0 and r.total_price > THRESHOLDS["anomaly_multiplier"] * avg_sale:
            warnings.append({
                "level": "warning",
                "message": f"Anomaly: {r.product_name} on {r.date} (₹{r.total_price:,.2f}) is {r.total_price/avg_sale:.1f}× the average sale.",
            })

    # Daily target breaches
    for dt, info in daily.items():
        if info["revenue"] < THRESHOLDS["daily_target"] * 0.5:
            warnings.append({
                "level": "critical",
                "message": f"Low revenue day: {dt} — only ₹{info['revenue']:,.2f} (below 50% of ₹{THRESHOLDS['daily_target']:,.0f} target).",
            })

    # Deduplicate
    seen = set()
    unique = []
    for w in warnings:
        key = w["message"]
        if key not in seen:
            seen.add(key)
            unique.append(w)
    return unique[:20]  # cap at 20 warnings


def search_records(
    records: List[SaleRecord],
    keyword: str = "",
    category: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    payment_method: Optional[str] = None,
) -> List[SaleRecord]:
    """
    Keyword and category-based filtering.
    Searches across product_name, customer_name, notes, sale_id.
    """
    results = records[:]

    if keyword:
        kw = keyword.lower()
        results = [
            r for r in results
            if kw in r.product_name.lower()
            or kw in r.customer_name.lower()
            or kw in r.notes.lower()
            or kw in r.sale_id.lower()
        ]

    if category:
        results = [r for r in results if r.category == category]

    if date_from:
        results = [r for r in results if r.date >= date_from]

    if date_to:
        results = [r for r in results if r.date <= date_to]

    if payment_method:
        results = [r for r in results if r.payment_method == payment_method]

    return results
