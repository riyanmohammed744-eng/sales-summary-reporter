"""
validation.py — Defensive input validation for Sales Summary Reporter.
Provides real-time sanitization and range checks for all user-submitted values.
"""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Tuple, Optional
from models import VALID_CATEGORIES, VALID_PAYMENT_METHODS


class ValidationError(Exception):
    """Raised when input validation fails."""
    pass


def validate_date(value: str) -> Tuple[bool, str]:
    """Validate date string in YYYY-MM-DD format."""
    if not value or not value.strip():
        return False, "Date cannot be empty."
    value = value.strip()
    pattern = r"^\d{4}-\d{2}-\d{2}$"
    if not re.match(pattern, value):
        return False, "Date must be in YYYY-MM-DD format (e.g., 2026-11-25)."
    try:
        parsed = datetime.strptime(value, "%Y-%m-%d").date()
        if parsed > date.today():
            return False, "Date cannot be in the future."
        if parsed.year < 2000:
            return False, "Date must be year 2000 or later."
    except ValueError:
        return False, "Invalid date. Please check day/month values."
    return True, ""


def validate_product_name(value: str) -> Tuple[bool, str]:
    """Validate product name: non-empty, 2–100 chars, alphanumeric + spaces."""
    if not value or not value.strip():
        return False, "Product name cannot be empty."
    value = value.strip()
    if len(value) < 2:
        return False, "Product name must be at least 2 characters."
    if len(value) > 100:
        return False, "Product name must be at most 100 characters."
    if not re.match(r"^[A-Za-z0-9\s\-&']+$", value):
        return False, "Product name contains invalid characters. Use letters, numbers, spaces, hyphens, &, or apostrophes."
    return True, ""


def validate_category(value: str) -> Tuple[bool, str]:
    """Validate category against allowed list."""
    if not value or not value.strip():
        return False, "Category cannot be empty."
    if value.strip() not in VALID_CATEGORIES:
        return False, f"Invalid category. Must be one of: {', '.join(VALID_CATEGORIES)}."
    return True, ""


def validate_quantity(value) -> Tuple[bool, str]:
    """Validate quantity: positive integer, 1–99999."""
    try:
        q = int(value)
    except (ValueError, TypeError):
        return False, "Quantity must be a whole number."
    if q < 1:
        return False, "Quantity must be at least 1."
    if q > 99999:
        return False, "Quantity cannot exceed 99,999."
    return True, ""


def validate_unit_price(value) -> Tuple[bool, str]:
    """Validate unit price: positive float, 0.01–9999999.99."""
    try:
        p = float(value)
    except (ValueError, TypeError):
        return False, "Unit price must be a number."
    if p < 0.01:
        return False, "Unit price must be at least ₹0.01."
    if p > 9999999.99:
        return False, "Unit price cannot exceed ₹99,99,999.99."
    return True, ""


def validate_payment_method(value: str) -> Tuple[bool, str]:
    """Validate payment method against allowed list."""
    if not value or not value.strip():
        return False, "Payment method cannot be empty."
    if value.strip() not in VALID_PAYMENT_METHODS:
        return False, f"Invalid payment method. Must be one of: {', '.join(VALID_PAYMENT_METHODS)}."
    return True, ""


def validate_customer_name(value: str) -> Tuple[bool, str]:
    """Validate customer name: optional, 0–100 chars."""
    if not value:
        return True, ""
    if len(value.strip()) > 100:
        return False, "Customer name must be at most 100 characters."
    return True, ""


def validate_csv_row(row: dict, row_num: int) -> Tuple[bool, list[str]]:
    """
    Validate a CSV row dictionary. Returns (is_valid, list_of_errors).
    Used for bulk import validation with row-by-row error logging.
    """
    errors = []

    ok, msg = validate_date(row.get("date", ""))
    if not ok:
        errors.append(f"Row {row_num}: date — {msg}")

    ok, msg = validate_product_name(row.get("product_name", ""))
    if not ok:
        errors.append(f"Row {row_num}: product_name — {msg}")

    ok, msg = validate_category(row.get("category", ""))
    if not ok:
        errors.append(f"Row {row_num}: category — {msg}")

    ok, msg = validate_quantity(row.get("quantity", ""))
    if not ok:
        errors.append(f"Row {row_num}: quantity — {msg}")

    ok, msg = validate_unit_price(row.get("unit_price", ""))
    if not ok:
        errors.append(f"Row {row_num}: unit_price — {msg}")

    pm = row.get("payment_method", "Cash")
    if pm:
        ok, msg = validate_payment_method(pm)
        if not ok:
            errors.append(f"Row {row_num}: payment_method — {msg}")

    return (len(errors) == 0, errors)
