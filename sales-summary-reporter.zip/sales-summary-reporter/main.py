"""
main.py — Sales Summary Reporter — NiceGUI Web Application
A comprehensive web-based sales analytics dashboard built with NiceGUI.

Features:
  • Dashboard with KPI cards and interactive charts
  • Full CRUD for sales records with defensive validation
  • Search & filter across all fields
  • Daily totals & product totals views
  • Threshold warning indicators
  • Bulk CSV import with row-by-row error reporting
  • Multi-format export (Markdown, CSV, plain-text audit log)
  • Persistent storage (CSV + JSON) surviving restarts

Run:  python main.py
Then open: http://localhost:8080
"""

from __future__ import annotations

import os
import sys
import io
import csv
from datetime import date, datetime
from typing import Optional

from nicegui import ui, app, events

# ── Ensure project root on sys.path ──────────────────────────────
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from models import SaleRecord, VALID_CATEGORIES, VALID_PAYMENT_METHODS, THRESHOLDS
from validation import (
    validate_date, validate_product_name, validate_category,
    validate_quantity, validate_unit_price, validate_payment_method,
    validate_customer_name,
)
from analytics import (
    compute_daily_totals, compute_product_totals, compute_category_totals,
    compute_payment_breakdown, compute_executive_summary, search_records,
)
from persistence import (
    load_from_json, save_to_json, load_from_csv, save_to_csv,
    export_markdown_report, export_csv_report, export_plaintext_log,
    bulk_import_csv, ensure_dirs, EXPORT_DIR, DATA_DIR,
)
from sample_data import generate_sample_data


# ══════════════════════════════════════════════════════════════════
#  GLOBAL STATE
# ══════════════════════════════════════════════════════════════════

class AppState:
    """Central application state loaded once at startup."""
    records: list[SaleRecord] = []
    summary: dict = {}

    @classmethod
    def load(cls):
        ensure_dirs()
        cls.records = load_from_json()
        if not cls.records:
            cls.records = load_from_csv()
        if not cls.records:
            cls.records = generate_sample_data(50)
            cls.persist()
        cls.refresh_summary()

    @classmethod
    def persist(cls):
        save_to_json(cls.records)
        save_to_csv(cls.records)

    @classmethod
    def refresh_summary(cls):
        cls.summary = compute_executive_summary(cls.records)

    @classmethod
    def add_record(cls, rec: SaleRecord):
        cls.records.append(rec)
        cls.persist()
        cls.refresh_summary()

    @classmethod
    def delete_record(cls, sale_id: str):
        cls.records = [r for r in cls.records if r.sale_id != sale_id]
        cls.persist()
        cls.refresh_summary()

    @classmethod
    def import_records(cls, new_records: list[SaleRecord]):
        cls.records.extend(new_records)
        cls.persist()
        cls.refresh_summary()


# Load state on import
AppState.load()


# ══════════════════════════════════════════════════════════════════
#  CUSTOM CSS
# ══════════════════════════════════════════════════════════════════

CUSTOM_CSS = """
<style>
:root {
    --primary: #2E7D32;
    --primary-light: #4CAF50;
    --primary-dark: #1B5E20;
    --accent: #FF9800;
    --bg-dark: #121212;
    --bg-card: #1E1E1E;
    --bg-card-hover: #2A2A2A;
    --text-primary: #FAFAFA;
    --text-secondary: #B0B0B0;
    --success: #4CAF50;
    --warning: #FF9800;
    --danger: #F44336;
    --info: #2196F3;
}

body {
    font-family: 'Inter', 'Segoe UI', sans-serif !important;
}

.kpi-card {
    background: linear-gradient(135deg, var(--bg-card), var(--bg-card-hover));
    border-radius: 16px;
    padding: 24px;
    border: 1px solid rgba(255,255,255,0.06);
    transition: transform 0.2s, box-shadow 0.2s;
}
.kpi-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.3);
}

.warning-banner {
    border-left: 4px solid var(--warning);
    background: rgba(255,152,0,0.08);
    padding: 12px 16px;
    border-radius: 0 8px 8px 0;
    margin: 4px 0;
}

.danger-banner {
    border-left: 4px solid var(--danger);
    background: rgba(244,67,54,0.08);
    padding: 12px 16px;
    border-radius: 0 8px 8px 0;
    margin: 4px 0;
}

.info-banner {
    border-left: 4px solid var(--info);
    background: rgba(33,150,243,0.08);
    padding: 12px 16px;
    border-radius: 0 8px 8px 0;
    margin: 4px 0;
}

.brand-header {
    background: linear-gradient(135deg, #1B5E20, #2E7D32, #388E3C);
    padding: 20px 32px;
    border-radius: 0 0 20px 20px;
}

.chart-container {
    background: var(--bg-card);
    border-radius: 16px;
    padding: 20px;
    border: 1px solid rgba(255,255,255,0.06);
}

.section-title {
    font-size: 1.3rem;
    font-weight: 700;
    color: var(--primary-light);
    margin-bottom: 12px;
}
</style>
"""


# ══════════════════════════════════════════════════════════════════
#  HELPER: ECharts options builders
# ══════════════════════════════════════════════════════════════════

def build_daily_revenue_chart(daily: dict) -> dict:
    sorted_dates = sorted(daily.keys())
    revenues = [round(daily[d]["revenue"], 2) for d in sorted_dates]
    counts = [daily[d]["count"] for d in sorted_dates]
    return {
        "tooltip": {"trigger": "axis"},
        "legend": {"data": ["Revenue (₹)", "Transactions"], "textStyle": {"color": "#B0B0B0"}},
        "xAxis": {"type": "category", "data": sorted_dates, "axisLabel": {"color": "#B0B0B0", "rotate": 45}},
        "yAxis": [
            {"type": "value", "name": "Revenue (₹)", "axisLabel": {"color": "#B0B0B0"}, "nameTextStyle": {"color": "#B0B0B0"}},
            {"type": "value", "name": "Transactions", "axisLabel": {"color": "#B0B0B0"}, "nameTextStyle": {"color": "#B0B0B0"}},
        ],
        "series": [
            {"name": "Revenue (₹)", "type": "bar", "data": revenues,
             "itemStyle": {"color": "#4CAF50", "borderRadius": [4, 4, 0, 0]}},
            {"name": "Transactions", "type": "line", "yAxisIndex": 1, "data": counts,
             "lineStyle": {"color": "#FF9800"}, "itemStyle": {"color": "#FF9800"}},
        ],
        "backgroundColor": "transparent",
        "grid": {"bottom": 80},
    }


def build_category_pie_chart(categories: dict) -> dict:
    data = [{"name": cat, "value": round(info["revenue"], 2)} for cat, info in categories.items()]
    data.sort(key=lambda x: x["value"], reverse=True)
    colors = ["#4CAF50", "#FF9800", "#2196F3", "#F44336", "#9C27B0",
              "#00BCD4", "#FFEB3B", "#795548", "#607D8B", "#E91E63", "#8BC34A", "#FF5722"]
    return {
        "tooltip": {"trigger": "item", "formatter": "{b}: ₹{c} ({d}%)"},
        "legend": {"orient": "vertical", "right": 10, "top": "center", "textStyle": {"color": "#B0B0B0"}},
        "series": [{
            "type": "pie", "radius": ["40%", "70%"],
            "avoidLabelOverlap": True,
            "itemStyle": {"borderRadius": 8, "borderColor": "#1E1E1E", "borderWidth": 2},
            "label": {"show": False},
            "emphasis": {"label": {"show": True, "fontSize": 14, "fontWeight": "bold"}},
            "data": data,
            "color": colors[:len(data)],
        }],
        "backgroundColor": "transparent",
    }


def build_product_bar_chart(products: dict) -> dict:
    sorted_prods = sorted(products.items(), key=lambda x: x[1]["revenue"], reverse=True)[:15]
    names = [p[0] for p in sorted_prods]
    revenues = [round(p[1]["revenue"], 2) for p in sorted_prods]
    return {
        "tooltip": {"trigger": "axis"},
        "xAxis": {"type": "value", "axisLabel": {"color": "#B0B0B0"}},
        "yAxis": {"type": "category", "data": names[::-1], "axisLabel": {"color": "#B0B0B0", "fontSize": 11}},
        "series": [{
            "type": "bar", "data": revenues[::-1],
            "itemStyle": {"color": "#2196F3", "borderRadius": [0, 4, 4, 0]},
        }],
        "backgroundColor": "transparent",
        "grid": {"left": 160, "right": 30},
    }


def build_payment_pie_chart(payments: dict) -> dict:
    data = [{"name": pm, "value": round(info["revenue"], 2)} for pm, info in payments.items()]
    colors = ["#4CAF50", "#2196F3", "#FF9800", "#9C27B0"]
    return {
        "tooltip": {"trigger": "item", "formatter": "{b}: ₹{c} ({d}%)"},
        "series": [{
            "type": "pie", "radius": ["35%", "65%"],
            "data": data,
            "color": colors[:len(data)],
            "itemStyle": {"borderRadius": 6, "borderColor": "#1E1E1E", "borderWidth": 2},
            "label": {"color": "#B0B0B0"},
        }],
        "backgroundColor": "transparent",
    }


# ══════════════════════════════════════════════════════════════════
#  PAGES
# ══════════════════════════════════════════════════════════════════

def create_header():
    """Branded header with navigation."""
    with ui.header().classes("bg-green-900 shadow-lg items-center justify-between px-6"):
        with ui.row().classes("items-center gap-3"):
            ui.icon("eco", size="sm").classes("text-green-300")
            ui.label("🌿 Sales Summary Reporter").classes("text-xl font-bold text-white tracking-wide")
            ui.label("GreenFuture Hack — Project #83").classes("text-green-300 text-sm ml-2")
        with ui.row().classes("gap-1"):
            ui.button("Dashboard", icon="dashboard", on_click=lambda: ui.navigate.to("/")).props("flat color=white")
            ui.button("Records", icon="table_chart", on_click=lambda: ui.navigate.to("/records")).props("flat color=white")
            ui.button("Analytics", icon="insights", on_click=lambda: ui.navigate.to("/analytics")).props("flat color=white")
            ui.button("Import / Export", icon="import_export", on_click=lambda: ui.navigate.to("/import-export")).props("flat color=white")


# ── DASHBOARD PAGE ────────────────────────────────────────────────

@ui.page("/")
def dashboard_page():
    ui.add_head_html(CUSTOM_CSS)
    create_header()
    s = AppState.summary

    with ui.column().classes("w-full max-w-7xl mx-auto p-6 gap-6"):
        # Welcome banner
        with ui.card().classes("w-full bg-green-900 text-white shadow-xl").style("border-radius: 16px"):
            with ui.card_section():
                ui.label("📊 Executive Dashboard").classes("text-2xl font-bold")
                ui.label(
                    f"Tracking {s.get('total_transactions', 0)} transactions across "
                    f"{s.get('unique_products', 0)} products | {s.get('date_range', 'N/A')}"
                ).classes("text-green-200 mt-1")

        # KPI Cards
        with ui.row().classes("w-full gap-4 flex-wrap"):
            kpi_data = [
                ("💰", "Total Revenue", f"₹{s.get('total_revenue', 0):,.2f}", "text-green-400"),
                ("📦", "Transactions", f"{s.get('total_transactions', 0):,}", "text-blue-400"),
                ("📊", "Units Sold", f"{s.get('total_units', 0):,}", "text-orange-400"),
                ("📈", "Avg Sale", f"₹{s.get('avg_sale_value', 0):,.2f}", "text-purple-400"),
                ("🏆", "Top Product", s.get("top_product", "N/A"), "text-yellow-400"),
                ("📅", "Best Day", s.get("busiest_day", "N/A"), "text-cyan-400"),
            ]
            for icon, title, value, color in kpi_data:
                with ui.card().classes("flex-1 min-w-[200px]").style(
                    "background: linear-gradient(135deg, #1E1E1E, #2A2A2A); border-radius: 16px; border: 1px solid rgba(255,255,255,0.06)"
                ):
                    with ui.card_section():
                        ui.label(f"{icon} {title}").classes("text-gray-400 text-sm font-medium")
                        ui.label(value).classes(f"text-2xl font-bold {color} mt-1")

        # Charts Row
        with ui.row().classes("w-full gap-6 flex-wrap"):
            with ui.card().classes("flex-1 min-w-[450px]").style("background: #1E1E1E; border-radius: 16px"):
                with ui.card_section():
                    ui.label("📈 Daily Revenue & Transactions").classes("text-lg font-bold text-green-400")
                if s.get("daily_totals"):
                    ui.echart(build_daily_revenue_chart(s["daily_totals"])).classes("w-full h-80")
                else:
                    ui.label("No data available").classes("text-gray-500 p-4")

            with ui.card().classes("flex-1 min-w-[350px]").style("background: #1E1E1E; border-radius: 16px"):
                with ui.card_section():
                    ui.label("🏷️ Revenue by Category").classes("text-lg font-bold text-green-400")
                if s.get("category_totals"):
                    ui.echart(build_category_pie_chart(s["category_totals"])).classes("w-full h-80")
                else:
                    ui.label("No data available").classes("text-gray-500 p-4")

        # Second charts row
        with ui.row().classes("w-full gap-6 flex-wrap"):
            with ui.card().classes("flex-1 min-w-[450px]").style("background: #1E1E1E; border-radius: 16px"):
                with ui.card_section():
                    ui.label("📦 Top Products by Revenue").classes("text-lg font-bold text-blue-400")
                if s.get("product_totals"):
                    ui.echart(build_product_bar_chart(s["product_totals"])).classes("w-full h-96")
                else:
                    ui.label("No data available").classes("text-gray-500 p-4")

            with ui.card().classes("flex-1 min-w-[300px]").style("background: #1E1E1E; border-radius: 16px"):
                with ui.card_section():
                    ui.label("💳 Payment Methods").classes("text-lg font-bold text-blue-400")
                if s.get("payment_breakdown"):
                    ui.echart(build_payment_pie_chart(s["payment_breakdown"])).classes("w-full h-80")
                else:
                    ui.label("No data available").classes("text-gray-500 p-4")

        # Warnings Section
        warnings = s.get("warnings", [])
        if warnings:
            with ui.card().classes("w-full").style("background: #1E1E1E; border-radius: 16px"):
                with ui.card_section():
                    ui.label(f"⚠️ Threshold Alerts ({len(warnings)})").classes("text-lg font-bold text-orange-400")
                with ui.card_section():
                    for w in warnings[:10]:
                        level = w.get("level", "info")
                        icon_map = {"critical": "🔴", "warning": "🟠", "info": "🔵"}
                        css_class = {"critical": "danger-banner", "warning": "warning-banner", "info": "info-banner"}
                        with ui.element("div").classes(css_class.get(level, "info-banner")):
                            ui.label(f"{icon_map.get(level, '🔵')} {w['message']}").classes("text-sm")


# ── RECORDS PAGE ──────────────────────────────────────────────────

@ui.page("/records")
def records_page():
    ui.add_head_html(CUSTOM_CSS)
    create_header()

    # State for search/filter
    search_state = {"keyword": "", "category": None, "payment": None}

    def get_filtered_records() -> list[SaleRecord]:
        return search_records(
            AppState.records,
            keyword=search_state["keyword"],
            category=search_state["category"],
            payment_method=search_state["payment"],
        )

    def refresh_table():
        rows = get_filtered_records()
        table_data = [
            {
                "sale_id": r.sale_id,
                "date": r.date,
                "product_name": r.product_name,
                "category": r.category,
                "quantity": r.quantity,
                "unit_price": f"₹{r.unit_price:,.2f}",
                "total_price": f"₹{r.total_price:,.2f}",
                "payment_method": r.payment_method,
                "customer_name": r.customer_name,
            }
            for r in rows
        ]
        sales_table.rows = table_data
        record_count_label.set_text(f"Showing {len(rows)} of {len(AppState.records)} records")

    def on_search_change(e):
        search_state["keyword"] = e.value or ""
        refresh_table()

    def on_category_change(e):
        search_state["category"] = e.value if e.value != "All" else None
        refresh_table()

    def on_payment_change(e):
        search_state["payment"] = e.value if e.value != "All" else None
        refresh_table()

    def delete_record(e):
        sale_id = e.args.get("sale_id", "") if isinstance(e.args, dict) else ""
        if sale_id:
            AppState.delete_record(sale_id)
            refresh_table()
            ui.notify(f"Record {sale_id} deleted", type="warning")

    with ui.column().classes("w-full max-w-7xl mx-auto p-6 gap-6"):
        ui.label("📋 Sales Records").classes("text-2xl font-bold text-green-400")

        # Search & Filter Bar
        with ui.card().classes("w-full").style("background: #1E1E1E; border-radius: 16px"):
            with ui.card_section():
                with ui.row().classes("w-full gap-4 items-end flex-wrap"):
                    ui.input(
                        label="🔍 Search records",
                        placeholder="Product, customer, ID...",
                        on_change=on_search_change,
                    ).classes("flex-1 min-w-[200px]")

                    ui.select(
                        label="Category",
                        options=["All"] + VALID_CATEGORIES,
                        value="All",
                        on_change=on_category_change,
                    ).classes("min-w-[180px]")

                    ui.select(
                        label="Payment Method",
                        options=["All"] + VALID_PAYMENT_METHODS,
                        value="All",
                        on_change=on_payment_change,
                    ).classes("min-w-[150px]")

                    ui.button("➕ Add Record", icon="add", on_click=lambda: ui.navigate.to("/add-record")).props("color=green")

        record_count_label = ui.label(f"Showing {len(AppState.records)} of {len(AppState.records)} records").classes("text-gray-400 text-sm")

        # Data table
        columns = [
            {"name": "sale_id", "label": "ID", "field": "sale_id", "sortable": True, "align": "left"},
            {"name": "date", "label": "Date", "field": "date", "sortable": True, "align": "left"},
            {"name": "product_name", "label": "Product", "field": "product_name", "sortable": True, "align": "left"},
            {"name": "category", "label": "Category", "field": "category", "sortable": True, "align": "left"},
            {"name": "quantity", "label": "Qty", "field": "quantity", "sortable": True, "align": "right"},
            {"name": "unit_price", "label": "Unit Price", "field": "unit_price", "sortable": True, "align": "right"},
            {"name": "total_price", "label": "Total", "field": "total_price", "sortable": True, "align": "right"},
            {"name": "payment_method", "label": "Payment", "field": "payment_method", "sortable": True, "align": "left"},
            {"name": "customer_name", "label": "Customer", "field": "customer_name", "sortable": True, "align": "left"},
        ]

        initial_rows = [
            {
                "sale_id": r.sale_id,
                "date": r.date,
                "product_name": r.product_name,
                "category": r.category,
                "quantity": r.quantity,
                "unit_price": f"₹{r.unit_price:,.2f}",
                "total_price": f"₹{r.total_price:,.2f}",
                "payment_method": r.payment_method,
                "customer_name": r.customer_name,
            }
            for r in AppState.records
        ]

        sales_table = ui.table(
            columns=columns,
            rows=initial_rows,
            row_key="sale_id",
            pagination={"rowsPerPage": 15, "sortBy": "date", "descending": True},
        ).classes("w-full").style("background: #1E1E1E; border-radius: 12px")
        sales_table.props("dark flat bordered dense")

        # Add a delete action slot
        sales_table.add_slot(
            "body-cell-sale_id",
            '''
            <q-td :props="props">
                <div class="row items-center no-wrap gap-2">
                    <span>{{ props.value }}</span>
                    <q-btn flat dense round icon="delete" size="xs" color="red"
                           @click="$parent.$emit('delete', props.row)" />
                </div>
            </q-td>
            '''
        )
        sales_table.on("delete", delete_record)


# ── ADD RECORD PAGE ───────────────────────────────────────────────

@ui.page("/add-record")
def add_record_page():
    ui.add_head_html(CUSTOM_CSS)
    create_header()

    form_data = {}
    error_labels = {}

    def clear_error(field_name):
        if field_name in error_labels:
            error_labels[field_name].set_text("")

    def show_error(field_name, msg):
        if field_name in error_labels:
            error_labels[field_name].set_text(msg)

    def submit_record():
        """Validate all fields and add record."""
        all_valid = True

        # Date
        ok, msg = validate_date(form_data.get("date", ""))
        if not ok:
            show_error("date", msg)
            all_valid = False
        else:
            clear_error("date")

        # Product name
        ok, msg = validate_product_name(form_data.get("product_name", ""))
        if not ok:
            show_error("product_name", msg)
            all_valid = False
        else:
            clear_error("product_name")

        # Category
        ok, msg = validate_category(form_data.get("category", ""))
        if not ok:
            show_error("category", msg)
            all_valid = False
        else:
            clear_error("category")

        # Quantity
        ok, msg = validate_quantity(form_data.get("quantity", ""))
        if not ok:
            show_error("quantity", msg)
            all_valid = False
        else:
            clear_error("quantity")

        # Unit price
        ok, msg = validate_unit_price(form_data.get("unit_price", ""))
        if not ok:
            show_error("unit_price", msg)
            all_valid = False
        else:
            clear_error("unit_price")

        # Payment method
        ok, msg = validate_payment_method(form_data.get("payment_method", "Cash"))
        if not ok:
            show_error("payment_method", msg)
            all_valid = False
        else:
            clear_error("payment_method")

        # Customer name (optional)
        ok, msg = validate_customer_name(form_data.get("customer_name", ""))
        if not ok:
            show_error("customer_name", msg)
            all_valid = False
        else:
            clear_error("customer_name")

        if not all_valid:
            ui.notify("❌ Please fix the errors above", type="negative")
            return

        rec = SaleRecord(
            date=form_data["date"],
            product_name=form_data["product_name"].strip(),
            category=form_data["category"],
            quantity=int(form_data["quantity"]),
            unit_price=float(form_data["unit_price"]),
            payment_method=form_data.get("payment_method", "Cash"),
            customer_name=form_data.get("customer_name", "Walk-in").strip() or "Walk-in",
            notes=form_data.get("notes", "").strip(),
        )
        AppState.add_record(rec)
        ui.notify(f"✅ Record {rec.sale_id} added successfully! Total: ₹{rec.total_price:,.2f}", type="positive")
        ui.navigate.to("/records")

    with ui.column().classes("w-full max-w-3xl mx-auto p-6 gap-4"):
        ui.label("➕ Add New Sale Record").classes("text-2xl font-bold text-green-400")
        ui.label("All fields are validated in real-time. Fix errors before submitting.").classes("text-gray-400")

        with ui.card().classes("w-full").style("background: #1E1E1E; border-radius: 16px"):
            with ui.card_section().classes("gap-4"):
                # Date
                with ui.column().classes("w-full gap-0"):
                    ui.input(
                        label="📅 Date (YYYY-MM-DD)",
                        placeholder="2026-11-25",
                        value=date.today().isoformat(),
                        on_change=lambda e: (form_data.update({"date": e.value}), clear_error("date")),
                    ).classes("w-full")
                    form_data["date"] = date.today().isoformat()
                    error_labels["date"] = ui.label("").classes("text-red-400 text-xs")

                # Product name
                with ui.column().classes("w-full gap-0"):
                    ui.input(
                        label="📦 Product Name",
                        placeholder="e.g. Wireless Mouse",
                        on_change=lambda e: (form_data.update({"product_name": e.value}), clear_error("product_name")),
                    ).classes("w-full")
                    error_labels["product_name"] = ui.label("").classes("text-red-400 text-xs")

                with ui.row().classes("w-full gap-4"):
                    # Category
                    with ui.column().classes("flex-1 gap-0"):
                        ui.select(
                            label="🏷️ Category",
                            options=VALID_CATEGORIES,
                            on_change=lambda e: (form_data.update({"category": e.value}), clear_error("category")),
                        ).classes("w-full")
                        error_labels["category"] = ui.label("").classes("text-red-400 text-xs")

                    # Payment method
                    with ui.column().classes("flex-1 gap-0"):
                        ui.select(
                            label="💳 Payment Method",
                            options=VALID_PAYMENT_METHODS,
                            value="Cash",
                            on_change=lambda e: (form_data.update({"payment_method": e.value}), clear_error("payment_method")),
                        ).classes("w-full")
                        form_data["payment_method"] = "Cash"
                        error_labels["payment_method"] = ui.label("").classes("text-red-400 text-xs")

                with ui.row().classes("w-full gap-4"):
                    # Quantity
                    with ui.column().classes("flex-1 gap-0"):
                        ui.number(
                            label="📊 Quantity",
                            min=1,
                            max=99999,
                            step=1,
                            value=1,
                            on_change=lambda e: (form_data.update({"quantity": e.value}), clear_error("quantity")),
                        ).classes("w-full")
                        form_data["quantity"] = 1
                        error_labels["quantity"] = ui.label("").classes("text-red-400 text-xs")

                    # Unit price
                    with ui.column().classes("flex-1 gap-0"):
                        ui.number(
                            label="💲 Unit Price (₹)",
                            min=0.01,
                            step=0.01,
                            format="%.2f",
                            on_change=lambda e: (form_data.update({"unit_price": e.value}), clear_error("unit_price")),
                        ).classes("w-full")
                        error_labels["unit_price"] = ui.label("").classes("text-red-400 text-xs")

                # Customer name
                with ui.column().classes("w-full gap-0"):
                    ui.input(
                        label="👤 Customer Name (optional)",
                        placeholder="Walk-in",
                        on_change=lambda e: form_data.update({"customer_name": e.value}),
                    ).classes("w-full")
                    error_labels["customer_name"] = ui.label("").classes("text-red-400 text-xs")

                # Notes
                ui.textarea(
                    label="📝 Notes (optional)",
                    placeholder="Any additional notes...",
                    on_change=lambda e: form_data.update({"notes": e.value}),
                ).classes("w-full")

        with ui.row().classes("gap-4 mt-2"):
            ui.button("✅ Add Record", icon="save", on_click=submit_record).props("color=green size=lg")
            ui.button("Cancel", icon="cancel", on_click=lambda: ui.navigate.to("/records")).props("flat color=grey")


# ── ANALYTICS PAGE ────────────────────────────────────────────────

@ui.page("/analytics")
def analytics_page():
    ui.add_head_html(CUSTOM_CSS)
    create_header()
    s = AppState.summary

    with ui.column().classes("w-full max-w-7xl mx-auto p-6 gap-6"):
        ui.label("📊 Detailed Analytics").classes("text-2xl font-bold text-green-400")

        # ── Daily Totals Table ────────────────────────────────────
        with ui.card().classes("w-full").style("background: #1E1E1E; border-radius: 16px"):
            with ui.card_section():
                ui.label("📅 Daily Totals").classes("text-lg font-bold text-green-400")

            daily = s.get("daily_totals", {})
            daily_rows = [
                {
                    "date": dt,
                    "transactions": info["count"],
                    "units": info["units"],
                    "revenue": f"₹{info['revenue']:,.2f}",
                    "avg_sale": f"₹{info.get('avg_sale', 0):,.2f}",
                    "status": "🟢 On Track" if info["revenue"] >= THRESHOLDS["daily_target"] else
                              "🟡 Below Target" if info["revenue"] >= THRESHOLDS["daily_target"] * 0.5 else "🔴 Critical",
                }
                for dt, info in sorted(daily.items())
            ]
            daily_cols = [
                {"name": "date", "label": "Date", "field": "date", "sortable": True, "align": "left"},
                {"name": "transactions", "label": "Transactions", "field": "transactions", "sortable": True, "align": "right"},
                {"name": "units", "label": "Units", "field": "units", "sortable": True, "align": "right"},
                {"name": "revenue", "label": "Revenue", "field": "revenue", "sortable": True, "align": "right"},
                {"name": "avg_sale", "label": "Avg Sale", "field": "avg_sale", "sortable": True, "align": "right"},
                {"name": "status", "label": "Status", "field": "status", "sortable": True, "align": "center"},
            ]
            dt_table = ui.table(columns=daily_cols, rows=daily_rows, row_key="date",
                                pagination={"rowsPerPage": 31}).classes("w-full")
            dt_table.props("dark flat bordered dense")

        # ── Product Totals Table ──────────────────────────────────
        with ui.card().classes("w-full").style("background: #1E1E1E; border-radius: 16px"):
            with ui.card_section():
                ui.label("📦 Product Totals").classes("text-lg font-bold text-blue-400")

            products = s.get("product_totals", {})
            prod_rows = [
                {
                    "product": prod,
                    "transactions": info["transactions"],
                    "units": f"{info['units']:,}",
                    "revenue": f"₹{info['revenue']:,.2f}",
                    "avg_price": f"₹{info.get('avg_price', 0):,.2f}",
                }
                for prod, info in sorted(products.items(), key=lambda x: x[1]["revenue"], reverse=True)
            ]
            prod_cols = [
                {"name": "product", "label": "Product", "field": "product", "sortable": True, "align": "left"},
                {"name": "transactions", "label": "Transactions", "field": "transactions", "sortable": True, "align": "right"},
                {"name": "units", "label": "Units Sold", "field": "units", "sortable": True, "align": "right"},
                {"name": "revenue", "label": "Revenue", "field": "revenue", "sortable": True, "align": "right"},
                {"name": "avg_price", "label": "Avg Unit Price", "field": "avg_price", "sortable": True, "align": "right"},
            ]
            pt_table = ui.table(columns=prod_cols, rows=prod_rows, row_key="product",
                                pagination={"rowsPerPage": 20}).classes("w-full")
            pt_table.props("dark flat bordered dense")

        # ── Category Breakdown ────────────────────────────────────
        with ui.card().classes("w-full").style("background: #1E1E1E; border-radius: 16px"):
            with ui.card_section():
                ui.label("🏷️ Category Breakdown").classes("text-lg font-bold text-purple-400")

            categories = s.get("category_totals", {})
            cat_rows = [
                {
                    "category": cat,
                    "transactions": info["count"],
                    "units": f"{info['units']:,}",
                    "revenue": f"₹{info['revenue']:,.2f}",
                    "share": f"{(info['revenue'] / s['total_revenue'] * 100):.1f}%" if s.get("total_revenue") else "0%",
                }
                for cat, info in sorted(categories.items(), key=lambda x: x[1]["revenue"], reverse=True)
            ]
            cat_cols = [
                {"name": "category", "label": "Category", "field": "category", "sortable": True, "align": "left"},
                {"name": "transactions", "label": "Transactions", "field": "transactions", "sortable": True, "align": "right"},
                {"name": "units", "label": "Units", "field": "units", "sortable": True, "align": "right"},
                {"name": "revenue", "label": "Revenue", "field": "revenue", "sortable": True, "align": "right"},
                {"name": "share", "label": "Share %", "field": "share", "sortable": True, "align": "right"},
            ]
            ct_table = ui.table(columns=cat_cols, rows=cat_rows, row_key="category").classes("w-full")
            ct_table.props("dark flat bordered dense")

        # ── Payment Methods ───────────────────────────────────────
        with ui.card().classes("w-full").style("background: #1E1E1E; border-radius: 16px"):
            with ui.card_section():
                ui.label("💳 Payment Method Breakdown").classes("text-lg font-bold text-orange-400")

            payments = s.get("payment_breakdown", {})
            pay_rows = [
                {
                    "method": pm,
                    "transactions": info["count"],
                    "revenue": f"₹{info['revenue']:,.2f}",
                    "share": f"{(info['revenue'] / s['total_revenue'] * 100):.1f}%" if s.get("total_revenue") else "0%",
                }
                for pm, info in payments.items()
            ]
            pay_cols = [
                {"name": "method", "label": "Method", "field": "method", "sortable": True, "align": "left"},
                {"name": "transactions", "label": "Transactions", "field": "transactions", "sortable": True, "align": "right"},
                {"name": "revenue", "label": "Revenue", "field": "revenue", "sortable": True, "align": "right"},
                {"name": "share", "label": "Share %", "field": "share", "sortable": True, "align": "right"},
            ]
            pm_table = ui.table(columns=pay_cols, rows=pay_rows, row_key="method").classes("w-full")
            pm_table.props("dark flat bordered dense")


# ── IMPORT / EXPORT PAGE ──────────────────────────────────────────

@ui.page("/import-export")
def import_export_page():
    ui.add_head_html(CUSTOM_CSS)
    create_header()

    with ui.column().classes("w-full max-w-5xl mx-auto p-6 gap-6"):
        ui.label("📥 Import / Export").classes("text-2xl font-bold text-green-400")

        # ── EXPORT SECTION ────────────────────────────────────────
        with ui.card().classes("w-full").style("background: #1E1E1E; border-radius: 16px"):
            with ui.card_section():
                ui.label("📤 Export Reports").classes("text-lg font-bold text-green-400")
                ui.label("Generate and download formatted reports from your sales data.").classes("text-gray-400 text-sm")

            with ui.card_section():
                with ui.row().classes("gap-4 flex-wrap"):
                    def export_md():
                        path = export_markdown_report(AppState.records, AppState.summary)
                        ui.notify(f"✅ Markdown report saved to: {path}", type="positive")

                    def export_csv():
                        path = export_csv_report(AppState.records)
                        ui.notify(f"✅ CSV export saved to: {path}", type="positive")

                    def export_txt():
                        path = export_plaintext_log(AppState.records, AppState.summary)
                        ui.notify(f"✅ Plain-text audit log saved to: {path}", type="positive")

                    def export_all():
                        p1 = export_markdown_report(AppState.records, AppState.summary)
                        p2 = export_csv_report(AppState.records)
                        p3 = export_plaintext_log(AppState.records, AppState.summary)
                        ui.notify(f"✅ All reports exported to exports/ directory", type="positive")

                    ui.button("📝 Markdown Report", icon="description", on_click=export_md).props("color=green")
                    ui.button("📊 CSV Export", icon="table_view", on_click=export_csv).props("color=blue")
                    ui.button("📄 Audit Log (TXT)", icon="article", on_click=export_txt).props("color=orange")
                    ui.button("📦 Export All", icon="download", on_click=export_all).props("color=purple")

                ui.label(f"Export directory: {EXPORT_DIR}").classes("text-gray-500 text-xs mt-2")

        # ── IMPORT SECTION ────────────────────────────────────────
        with ui.card().classes("w-full").style("background: #1E1E1E; border-radius: 16px"):
            with ui.card_section():
                ui.label("📥 Bulk CSV Import").classes("text-lg font-bold text-blue-400")
                ui.label(
                    "Upload a CSV file with columns: date, product_name, category, quantity, unit_price, payment_method, customer_name, notes. "
                    "Each row is validated individually with detailed error reporting."
                ).classes("text-gray-400 text-sm")

            with ui.card_section():
                import_log_area = ui.textarea(label="Import Log", value="").classes("w-full").props("readonly outlined dark")

                async def handle_upload(e: events.UploadEventArguments):
                    try:
                        content = e.content.read().decode("utf-8-sig")
                        # Save temp file
                        tmp_path = os.path.join(DATA_DIR, "_import_tmp.csv")
                        with open(tmp_path, "w", encoding="utf-8") as f:
                            f.write(content)

                        valid_records, errors = bulk_import_csv(tmp_path)

                        log_lines = [f"📄 File: {e.name}", f"Total rows processed: {len(valid_records) + len(errors)}", ""]

                        if valid_records:
                            AppState.import_records(valid_records)
                            log_lines.append(f"✅ Successfully imported {len(valid_records)} records.")
                        else:
                            log_lines.append("⚠️ No valid records found.")

                        if errors:
                            log_lines.append(f"\n❌ {len(errors)} validation errors:")
                            log_lines.extend(errors[:50])
                            if len(errors) > 50:
                                log_lines.append(f"... and {len(errors) - 50} more errors")

                        import_log_area.value = "\n".join(log_lines)
                        ui.notify(
                            f"Import complete: {len(valid_records)} added, {len(errors)} errors",
                            type="positive" if valid_records else "warning",
                        )

                        # Cleanup
                        try:
                            os.remove(tmp_path)
                        except OSError:
                            pass

                    except Exception as ex:
                        import_log_area.value = f"❌ Import failed: {ex}"
                        ui.notify(f"Import failed: {ex}", type="negative")

                ui.upload(
                    label="Choose CSV file",
                    on_upload=handle_upload,
                    auto_upload=True,
                ).props("accept=.csv color=blue-grey").classes("w-full max-w-md")

        # ── SEED DATA ─────────────────────────────────────────────
        with ui.card().classes("w-full").style("background: #1E1E1E; border-radius: 16px"):
            with ui.card_section():
                ui.label("🌱 Sample Data").classes("text-lg font-bold text-orange-400")
                ui.label("Reset and seed the database with 50 sample records for demonstration.").classes("text-gray-400 text-sm")

            with ui.card_section():
                async def reseed():
                    AppState.records = generate_sample_data(50)
                    AppState.persist()
                    AppState.refresh_summary()
                    ui.notify("✅ Database reseeded with 50 sample records!", type="positive")

                ui.button("🔄 Reseed Sample Data", icon="refresh", on_click=reseed).props("color=orange")


# ══════════════════════════════════════════════════════════════════
#  APP STARTUP
# ══════════════════════════════════════════════════════════════════

ui.run(
    title="🌿 Sales Summary Reporter — GreenFuture Hack",
    favicon="🌿",
    dark=True,
    port=8085,
    reload=False,
    show=False,
)
