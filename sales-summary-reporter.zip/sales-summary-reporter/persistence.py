"""
persistence.py — Local data persistence layer for Sales Summary Reporter.
Handles reading/writing structured records to CSV and JSON files
with robust error handling for corrupted or missing files.
"""

from __future__ import annotations

import csv
import json
import os
import shutil
from datetime import datetime
from typing import List, Tuple

from models import SaleRecord
from validation import validate_csv_row

# Default paths
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
CSV_FILE = os.path.join(DATA_DIR, "sales_data.csv")
JSON_FILE = os.path.join(DATA_DIR, "sales_data.json")
EXPORT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "exports")

CSV_HEADERS = [
    "sale_id", "date", "product_name", "category",
    "quantity", "unit_price", "total_price",
    "payment_method", "customer_name", "notes",
]


def ensure_dirs():
    """Create data and export directories if they don't exist."""
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(EXPORT_DIR, exist_ok=True)


# ── JSON Persistence ─────────────────────────────────────────────

def load_from_json(filepath: str = JSON_FILE) -> List[SaleRecord]:
    """Load sales records from JSON file with error handling."""
    ensure_dirs()
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError("JSON root must be a list.")
        return [SaleRecord.from_dict(d) for d in data]
    except FileNotFoundError:
        return []
    except (json.JSONDecodeError, ValueError, KeyError) as e:
        # Backup corrupted file and start fresh
        backup = filepath + f".corrupt.{datetime.now().strftime('%Y%m%d%H%M%S')}"
        shutil.copy2(filepath, backup)
        return []


def save_to_json(records: List[SaleRecord], filepath: str = JSON_FILE) -> None:
    """Persist records to JSON file atomically."""
    ensure_dirs()
    tmp = filepath + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump([r.to_dict() for r in records], f, indent=2, ensure_ascii=False)
    os.replace(tmp, filepath)


# ── CSV Persistence ───────────────────────────────────────────────

def load_from_csv(filepath: str = CSV_FILE) -> List[SaleRecord]:
    """Load sales records from CSV file with error handling."""
    ensure_dirs()
    try:
        with open(filepath, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            records = []
            for row in reader:
                try:
                    records.append(SaleRecord.from_dict(row))
                except (ValueError, KeyError):
                    continue  # skip malformed rows
            return records
    except FileNotFoundError:
        return []
    except Exception:
        return []


def save_to_csv(records: List[SaleRecord], filepath: str = CSV_FILE) -> None:
    """Persist records to CSV file."""
    ensure_dirs()
    tmp = filepath + ".tmp"
    with open(tmp, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_HEADERS)
        writer.writeheader()
        for r in records:
            writer.writerow(r.to_dict())
    os.replace(tmp, filepath)


# ── Bulk Import ───────────────────────────────────────────────────

def bulk_import_csv(filepath: str) -> Tuple[List[SaleRecord], List[str]]:
    """
    Import a CSV file with row-by-row validation.
    Returns (valid_records, error_log).
    """
    valid = []
    errors = []
    try:
        with open(filepath, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for i, row in enumerate(reader, start=2):  # row 1 = header
                ok, row_errors = validate_csv_row(row, i)
                if ok:
                    valid.append(SaleRecord.from_dict(row))
                else:
                    errors.extend(row_errors)
    except FileNotFoundError:
        errors.append(f"File not found: {filepath}")
    except Exception as e:
        errors.append(f"Error reading file: {e}")
    return valid, errors


# ── Export Functions ──────────────────────────────────────────────

def export_markdown_report(records: List[SaleRecord], summary: dict) -> str:
    """Generate a Markdown report and save to exports directory."""
    ensure_dirs()
    lines = [
        "# 📊 Sales Summary Report",
        f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"**Total Records:** {len(records)}",
        "",
        "## Overview",
        f"| Metric | Value |",
        f"|--------|-------|",
        f"| Total Revenue | ₹{summary.get('total_revenue', 0):,.2f} |",
        f"| Total Transactions | {summary.get('total_transactions', 0)} |",
        f"| Total Units Sold | {summary.get('total_units', 0):,} |",
        f"| Average Sale Value | ₹{summary.get('avg_sale_value', 0):,.2f} |",
        f"| Unique Products | {summary.get('unique_products', 0)} |",
        f"| Date Range | {summary.get('date_range', 'N/A')} |",
        "",
        "## Daily Totals",
        "| Date | Transactions | Revenue |",
        "|------|-------------|---------|",
    ]
    for dt, info in sorted(summary.get("daily_totals", {}).items()):
        lines.append(f"| {dt} | {info['count']} | ₹{info['revenue']:,.2f} |")

    lines.extend(["", "## Product Totals",
                   "| Product | Units Sold | Revenue |",
                   "|---------|-----------|---------|"])
    for prod, info in sorted(summary.get("product_totals", {}).items(),
                             key=lambda x: x[1]["revenue"], reverse=True):
        lines.append(f"| {prod} | {info['units']:,} | ₹{info['revenue']:,.2f} |")

    lines.extend(["", "## Category Breakdown",
                   "| Category | Transactions | Revenue |",
                   "|----------|-------------|---------|"])
    for cat, info in sorted(summary.get("category_totals", {}).items(),
                            key=lambda x: x[1]["revenue"], reverse=True):
        lines.append(f"| {cat} | {info['count']} | ₹{info['revenue']:,.2f} |")

    content = "\n".join(lines)
    path = os.path.join(EXPORT_DIR, f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md")
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


def export_csv_report(records: List[SaleRecord]) -> str:
    """Export records as a clean CSV report."""
    ensure_dirs()
    path = os.path.join(EXPORT_DIR, f"export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv")
    save_to_csv(records, path)
    return path


def export_plaintext_log(records: List[SaleRecord], summary: dict) -> str:
    """Export a plain-text audit log."""
    ensure_dirs()
    lines = [
        "=" * 60,
        "       SALES SUMMARY REPORTER — AUDIT LOG",
        "=" * 60,
        f"  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"  Records:   {len(records)}",
        "-" * 60,
        "",
    ]
    for r in records:
        lines.append(
            f"  [{r.sale_id}] {r.date} | {r.product_name:<25} | "
            f"Qty: {r.quantity:>5} × ₹{r.unit_price:>10,.2f} = ₹{r.total_price:>12,.2f}"
        )
    lines.extend([
        "",
        "-" * 60,
        f"  TOTAL REVENUE: ₹{summary.get('total_revenue', 0):,.2f}",
        "=" * 60,
    ])
    content = "\n".join(lines)
    path = os.path.join(EXPORT_DIR, f"audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path
