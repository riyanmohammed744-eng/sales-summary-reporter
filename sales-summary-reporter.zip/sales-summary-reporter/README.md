# 🌿 Sales Summary Reporter

**GreenFuture Hack — Project #83** | Domain: Small Business & Retail

A robust, beginner-friendly Python web application that reads sales records from CSV and calculates daily and product totals, featuring strict input validation, reliable local file persistence (CSV/JSON), interactive charts, and clear summary reporting — all through a modern NiceGUI web interface.

---

## ✨ Features

### Core Features (Must-Have)
- **Interactive Web Interface** — Beautiful dark-themed dashboard with NiceGUI, featuring navigation bar, KPI cards, and interactive charts
- **Defensive Input Validation** — Real-time field validation with clear error messages on the Add Record form
- **Core Business Logic Engine** — Computes daily totals, product totals, category breakdowns, and payment method analytics
- **Local Data Persistence** — Automatic read/write to both CSV and JSON files; data survives restarts
- **Record Query & Search** — Keyword search + category/payment method filtering on the Records page
- **Executive Summary Generation** — Dashboard with aggregated totals, averages, top products, busiest days, and trend charts

### Stretch Features (Good-to-Have)
- **Multi-Format Export** — Generate Markdown reports, CSV exports, and plain-text audit logs
- **Threshold Warning Indicators** — Automated alerts for high-value sales, anomalies, and low-revenue days
- **Interactive Web GUI** — Full NiceGUI web application with ECharts visualizations
- **Bulk CSV Import** — Upload CSV files with automatic row-by-row validation and error reporting

---

## 🚀 Quick Start

### 1. Prerequisites
- Python 3.10+

### 2. Setup
```bash
cd sales-summary-reporter

# Create virtual environment
python3 -m venv venv
source venv/bin/activate    # macOS/Linux
# venv\Scripts\activate     # Windows

# Install dependencies
pip install -r requirements.txt
```

### 3. Run
```bash
python main.py
```

Then open **http://localhost:8080** in your browser.

The app auto-seeds 50 sample records on first launch for immediate demo readiness.

---

## 📂 Project Structure

```
sales-summary-reporter/
├── main.py               # NiceGUI web app (entry point)
├── models.py             # Data structures (SaleRecord dataclass)
├── validation.py         # Defensive input validation
├── analytics.py          # Business logic (totals, summaries, search)
├── persistence.py        # CSV/JSON read/write & export functions
├── sample_data.py        # Realistic 50-record sample data generator
├── requirements.txt      # Python dependencies
├── data/                 # Persistent storage (auto-created)
│   ├── sales_data.csv
│   └── sales_data.json
└── exports/              # Generated reports (auto-created)
    ├── report_*.md
    ├── export_*.csv
    └── audit_*.txt
```

---

## 🖥️ Pages

| Page | URL | Description |
|------|-----|-------------|
| **Dashboard** | `/` | KPI cards, daily revenue chart, category pie chart, product rankings, payment breakdown, threshold alerts |
| **Records** | `/records` | Searchable, sortable, paginated data table with keyword/category/payment filters and delete actions |
| **Add Record** | `/add-record` | Validated form with real-time error feedback for all fields |
| **Analytics** | `/analytics` | Detailed tables: daily totals with status indicators, product totals, category breakdown, payment breakdown |
| **Import/Export** | `/import-export` | Bulk CSV import with error log; export to Markdown, CSV, or plain-text; reseed sample data |

---

## 📊 Sample Data

The app ships with a generator that creates 50 realistic sales records across:
- **9 categories**: Electronics, Groceries, Clothing, Stationery, Beverages, Snacks, Personal Care, Home & Kitchen, Books
- **28 products** with realistic pricing
- **16 customers** (mix of named and walk-in)
- **4 payment methods**: Cash, Card, UPI, Online
- **Edge cases**: minimum quantity (1), very low price (₹0.50), high-value sale (₹999,999), boundary quantities

---

## 🏆 Demo Flow

1. **Launch** — Start the app, see the branded dashboard with KPI cards and charts
2. **Add Record** — Navigate to Add Record, intentionally enter invalid data to show validation, then submit correctly
3. **Search** — Use the Records page to search by keyword and filter by category
4. **Analytics** — View detailed daily/product/category tables with status indicators
5. **Export** — Generate Markdown report and CSV export
6. **Persistence** — Close the app, relaunch, verify all data is preserved
7. **Import** — Upload an external CSV to demonstrate bulk import with error reporting

---

## 📄 License

Built for GreenFuture Hackathon 2026 — Project #83.
