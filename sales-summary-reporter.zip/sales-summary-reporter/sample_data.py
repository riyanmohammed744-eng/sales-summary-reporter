"""
sample_data.py — Generates a realistic sample dataset with 50 entries.
Includes normal entries, boundary values, and varied test cases.
"""

import random
import uuid
from datetime import date, timedelta

from models import SaleRecord, VALID_CATEGORIES, VALID_PAYMENT_METHODS
from persistence import save_to_csv, save_to_json

# Realistic product catalog
PRODUCTS = {
    "Electronics": [
        ("USB-C Charging Cable", 199.0),
        ("Wireless Mouse", 549.0),
        ("Bluetooth Speaker", 1299.0),
        ("Power Bank 10000mAh", 899.0),
        ("LED Desk Lamp", 749.0),
        ("Laptop Stand", 1499.0),
    ],
    "Groceries": [
        ("Basmati Rice 5kg", 425.0),
        ("Olive Oil 1L", 650.0),
        ("Whole Wheat Flour 10kg", 380.0),
        ("Mixed Dal Pack", 220.0),
        ("Organic Honey 500g", 349.0),
    ],
    "Clothing": [
        ("Cotton T-Shirt", 399.0),
        ("Denim Jeans", 1299.0),
        ("Sports Socks Pack", 199.0),
        ("Winter Jacket", 2499.0),
    ],
    "Stationery": [
        ("Notebook A4 Pack", 180.0),
        ("Gel Pen Set 10pc", 150.0),
        ("Highlighter Set", 120.0),
        ("Stapler with Pins", 95.0),
    ],
    "Beverages": [
        ("Green Tea Box 25pc", 175.0),
        ("Cold Brew Coffee 500ml", 280.0),
        ("Mango Juice 1L", 85.0),
        ("Mineral Water Case", 240.0),
    ],
    "Snacks": [
        ("Mixed Nuts 500g", 450.0),
        ("Protein Bars 6-Pack", 540.0),
        ("Dark Chocolate 200g", 220.0),
        ("Trail Mix 300g", 310.0),
    ],
    "Personal Care": [
        ("Sunscreen SPF50", 349.0),
        ("Shampoo 500ml", 275.0),
        ("Hand Sanitizer 500ml", 149.0),
    ],
    "Home & Kitchen": [
        ("Stainless Steel Bottle", 599.0),
        ("Chopping Board Set", 450.0),
        ("Kitchen Towel Roll 4pc", 180.0),
    ],
    "Books": [
        ("Python Programming Guide", 599.0),
        ("Data Science Handbook", 849.0),
        ("Bestseller Novel", 350.0),
    ],
}

CUSTOMERS = [
    "Walk-in", "Aarav Patel", "Priya Sharma", "Rahul Gupta",
    "Sneha Reddy", "Vikram Singh", "Ananya Das", "Kiran Joshi",
    "Meera Nair", "Arjun Kapoor", "Diya Mehta", "Walk-in",
    "Rohan Malhotra", "Ishita Bose", "Walk-in", "Neha Kulkarni",
]


def generate_sample_data(num_records: int = 50) -> list[SaleRecord]:
    """Generate realistic sample sales records."""
    random.seed(42)
    records = []
    start_date = date(2026, 11, 1)

    for i in range(num_records):
        # Spread across ~25 days
        sale_date = start_date + timedelta(days=random.randint(0, 24))
        category = random.choice(list(PRODUCTS.keys()))
        product_name, base_price = random.choice(PRODUCTS[category])

        # Vary price slightly (±10%)
        unit_price = round(base_price * random.uniform(0.9, 1.1), 2)
        quantity = random.choices(
            [1, 2, 3, 5, 10, 15, 25],
            weights=[30, 25, 15, 10, 8, 7, 5],
            k=1,
        )[0]

        # Edge cases
        if i == 0:
            quantity = 1  # minimum boundary
            unit_price = 0.50  # very low price boundary
        elif i == 1:
            quantity = 99999  # max boundary (stretch)
            unit_price = 0.01
        elif i == 48:
            quantity = 100
            unit_price = 9999.99  # high-value sale trigger

        record = SaleRecord(
            sale_id=uuid.uuid4().hex[:8].upper(),
            date=sale_date.isoformat(),
            product_name=product_name,
            category=category,
            quantity=quantity,
            unit_price=unit_price,
            payment_method=random.choice(VALID_PAYMENT_METHODS),
            customer_name=random.choice(CUSTOMERS),
            notes=random.choice(["", "", "", "Bulk order", "Gift wrap", "Return requested", "Discount applied"]),
        )
        records.append(record)

    return records


def seed_data():
    """Generate and persist sample data to both CSV and JSON."""
    records = generate_sample_data(50)
    save_to_csv(records)
    save_to_json(records)
    print(f"✅ Seeded {len(records)} sample records to data/sales_data.csv and data/sales_data.json")
    return records


if __name__ == "__main__":
    seed_data()
